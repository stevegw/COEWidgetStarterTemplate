// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


console.log($scope.app);

$scope.BuildWidgets = function() {
  
  $scope.setWidgetProp( "widgetCoe-1", "incomingresource", "app/resources/Uploaded/widgets.json");
  
}