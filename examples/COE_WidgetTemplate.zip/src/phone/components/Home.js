// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available




$scope.CompletedAction = function () {
  
  
  twx.app.fn.addSnackbarMessage("Action completed");
  
  
}